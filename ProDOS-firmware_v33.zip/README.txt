NVRAM DRIVE, (c)1995-2022 by Ralle Palaveev

This version is for the 512kB NVRAM DRIVE below hardware version 2.

128kB RAM required.

Use hardware and/or software at your own risk. No warranty taken.
No responsibility taken for any untoward effects or damage to hardware of any kind.

The 512kB file is the full firmware
The 140kB files contain the tools to be used with the card while in the Apple II

V33

The toos can format back-up and restore the NVRAM DRIVE

The disks has a full image of the current version and programs (version update)

Instructions:

1. Install NVRAM DRIVE in one slot
2. Mount the disk with "Program" in the name in an emulator or floppy
3. Boot from the image and follow the instructions

Change log:

V33 - 30 Mar 2022, changed buffer to addresses $6000-$7100, $BF98 zeroed at startup
V30 - 20 Mar 2022, All ZP addresses used by the firmwatre are restored on exit
V29 - 19 Mar 2022, Fixed incompatibility when copying with Copy+
V28 - 05 Jan 2022, Initial official version
